/*
 * Decompiled with CFR 0.150.
 */
package ru.hld.legendline.impl.modules.Render;

import ru.hld.legendline.api.module.Category;
import ru.hld.legendline.api.module.Module;

public class NoHurtCam
extends Module {
    public NoHurtCam() {
        super("NoHurtCam", "disable ", Category.Render);
        NoHurtCam lllllllllllllllIIIIIIlIlllIllIIl;
    }
}

