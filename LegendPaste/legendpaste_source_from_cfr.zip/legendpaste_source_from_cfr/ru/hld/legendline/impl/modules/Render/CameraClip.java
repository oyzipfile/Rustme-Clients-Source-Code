/*
 * Decompiled with CFR 0.150.
 */
package ru.hld.legendline.impl.modules.Render;

import ru.hld.legendline.api.module.Category;
import ru.hld.legendline.api.module.Module;

public class CameraClip
extends Module {
    public CameraClip() {
        super("CameraClip", "clipping camera", Category.Render);
        CameraClip lllllllllllllIllllIlIllllIlIIllI;
    }
}

