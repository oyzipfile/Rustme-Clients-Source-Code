/*
 * Decompiled with CFR 0.150.
 */
package ru.hld.legendline.impl.modules.Render;

import ru.hld.legendline.api.module.Category;
import ru.hld.legendline.api.module.Module;

public class ItemPhysics
extends Module {
    public ItemPhysics() {
        super("ItemPhysics", "enable physics to items", Category.Render);
        ItemPhysics lllllllllllllIlllllIIlIlIIllllll;
    }
}

