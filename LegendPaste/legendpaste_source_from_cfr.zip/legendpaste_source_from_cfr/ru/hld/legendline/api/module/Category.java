/*
 * Decompiled with CFR 0.150.
 */
package ru.hld.legendline.api.module;

public enum Category {
    Combat,
    Player,
    Movement,
    Render,
    Misc,
    Config;


    private Category() {
        Category llllllllllllllIIIllllIIlIIlIIlII;
    }
}

