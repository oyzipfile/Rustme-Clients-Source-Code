/*
 * Decompiled with CFR 0.150.
 */
package ru.hld.legendline.api.clickgui;

import java.io.IOException;

public class Comp {
    public void initGui() {
    }

    public float getHeight() {
        return 10.0f;
    }

    public void drawScreen(int lllllllllllllllIIlIIllllllIlIIII, int lllllllllllllllIIlIIllllllIIllll, int lllllllllllllllIIlIIllllllIIlllI, int lllllllllllllllIIlIIllllllIIllIl, float lllllllllllllllIIlIIllllllIIllII) {
    }

    public float getWidth() {
        return 100.0f;
    }

    public boolean ishover(float lllllllllllllllIIlIIlllllIlllIlI, float lllllllllllllllIIlIIlllllIllIIll, float lllllllllllllllIIlIIlllllIllIIlI, float lllllllllllllllIIlIIlllllIllIIIl, int lllllllllllllllIIlIIlllllIllIllI, int lllllllllllllllIIlIIlllllIlIllll) {
        return (float)lllllllllllllllIIlIIlllllIllIllI >= lllllllllllllllIIlIIlllllIlllIlI && (float)lllllllllllllllIIlIIlllllIllIllI <= lllllllllllllllIIlIIlllllIllIIlI && (float)lllllllllllllllIIlIIlllllIlIllll >= lllllllllllllllIIlIIlllllIllIIll && (float)lllllllllllllllIIlIIlllllIlIllll <= lllllllllllllllIIlIIlllllIllIIIl;
    }

    public void mouseClicked(int lllllllllllllllIIlIIllllllIIlIII, int lllllllllllllllIIlIIllllllIIIlll, int lllllllllllllllIIlIIllllllIIIllI, int lllllllllllllllIIlIIllllllIIIlIl, int lllllllllllllllIIlIIllllllIIIlII) throws IOException {
    }

    public Comp() {
        Comp lllllllllllllllIIlIIllllllIlIIlI;
    }

    public void reset() {
    }
}

