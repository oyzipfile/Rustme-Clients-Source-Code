/*
 * Decompiled with CFR 0.150.
 */
package ru.hld.legendline.api.event.events;

import ru.hld.legendline.api.event.Event;

public class EventRender2D
extends Event {
    /* synthetic */ float partialTicks;

    public EventRender2D(float lllllllllllllIllIlllllllIlIllIIl) {
        EventRender2D lllllllllllllIllIlllllllIlIlllII;
        lllllllllllllIllIlllllllIlIlllII.partialTicks = lllllllllllllIllIlllllllIlIllIIl;
    }

    public float getPartialTicks() {
        EventRender2D lllllllllllllIllIlllllllIlIlIllI;
        return lllllllllllllIllIlllllllIlIlIllI.partialTicks;
    }
}

