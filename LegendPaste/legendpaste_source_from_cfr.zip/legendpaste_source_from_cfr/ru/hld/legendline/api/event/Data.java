/*
 * Decompiled with CFR 0.150.
 */
package ru.hld.legendline.api.event;

import java.lang.reflect.Method;

public class Data {
    public final /* synthetic */ Method target;
    public final /* synthetic */ byte priority;
    public final /* synthetic */ Object source;

    public Data(Object lllllllllllllIlllIlIIlIIllIlIIll, Method lllllllllllllIlllIlIIlIIllIlIIlI, byte lllllllllllllIlllIlIIlIIllIlIlIl) {
        Data lllllllllllllIlllIlIIlIIllIlIlII;
        lllllllllllllIlllIlIIlIIllIlIlII.source = lllllllllllllIlllIlIIlIIllIlIIll;
        lllllllllllllIlllIlIIlIIllIlIlII.target = lllllllllllllIlllIlIIlIIllIlIIlI;
        lllllllllllllIlllIlIIlIIllIlIlII.priority = lllllllllllllIlllIlIIlIIllIlIlIl;
    }
}

