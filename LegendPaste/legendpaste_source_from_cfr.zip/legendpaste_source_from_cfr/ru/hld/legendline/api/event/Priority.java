/*
 * Decompiled with CFR 0.150.
 */
package ru.hld.legendline.api.event;

public class Priority {
    public static final /* synthetic */ byte THIRD;
    public static final /* synthetic */ byte FIFTH;
    public static final /* synthetic */ byte FIRST;
    public static final /* synthetic */ byte FOURTH;
    public static final /* synthetic */ byte[] VALUE_ARRAY;
    public static final /* synthetic */ byte SECOND;

    static {
        FOURTH = (byte)3;
        THIRD = (byte)2;
        FIFTH = (byte)4;
        SECOND = 1;
        FIRST = 0;
        VALUE_ARRAY = new byte[]{0, 1, 2, 3, 4};
    }

    public Priority() {
        Priority lllllllllllllllllIIlIIlllIIIIIIl;
    }
}

