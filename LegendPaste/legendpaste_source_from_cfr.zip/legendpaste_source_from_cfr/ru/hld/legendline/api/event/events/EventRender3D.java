/*
 * Decompiled with CFR 0.150.
 */
package ru.hld.legendline.api.event.events;

import ru.hld.legendline.api.event.Event;

public class EventRender3D
extends Event {
    /* synthetic */ float partialTicks;

    public EventRender3D(float lllllllllllllllIlllIIlllIllIllII) {
        EventRender3D lllllllllllllllIlllIIlllIllIlIll;
        lllllllllllllllIlllIIlllIllIlIll.partialTicks = lllllllllllllllIlllIIlllIllIllII;
    }

    public float getPartialTicks() {
        EventRender3D lllllllllllllllIlllIIlllIllIIlll;
        return lllllllllllllllIlllIIlllIllIIlll.partialTicks;
    }
}

