/*
 * Decompiled with CFR 0.150.
 */
package ru.hld.legendline.api.event.events;

import ru.hld.legendline.api.event.Event;

public class EventKeyBoard
extends Event {
    /* synthetic */ int key;

    public int getKey() {
        EventKeyBoard lIlIllllIIIIIlI;
        return lIlIllllIIIIIlI.key;
    }

    public EventKeyBoard(int lIlIllllIIIIlII) {
        EventKeyBoard lIlIllllIIIIlll;
        lIlIllllIIIIlll.key = lIlIllllIIIIlII;
    }
}

